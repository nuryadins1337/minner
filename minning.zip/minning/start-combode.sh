#!/bin/bash

while true
do
./wildrig-multi --print-full --algo phi5 --url stratum+tcp://stratum-eu.rplant.xyz:7055 --user CYc9adyF7SB3L7u2vrPph5mPM6EfMcdZJe --pass x
sleep 5
done
