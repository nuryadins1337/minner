#!/bin/bash

while true
do
./wildrig-multi --print-full --algo x25x --opencl-threads auto --opencl-launch auto --url stratum+tcp://eupool.sinovate.io:3253 --user SauLQKggrWaAcFU8BvZCJ2bEHAYb8QdpQY --pass c=SIN
sleep 5
done
