#!/bin/bash

while true
do
./wildrig-multi --print-full --algo x17r --opencl-threads auto --opencl-launch auto --url stratum+tcp://ufo.666pool.cn:7558 --user 10f970adcbb913b8d0fbff0d4e517190ec6dc1cffae3b6eb82356360f762a233b37.donate --pass x
sleep 5
done
