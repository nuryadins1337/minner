#!/bin/bash

while true
do
./wildrig-multi --print-full --algo megabtx --url stratum+tcp://stratum-eu.rplant.xyz:7066 --user seERaNvr5XL2ArCng6WmT7DXF5pXEixaAb --pass
sleep 5
done
